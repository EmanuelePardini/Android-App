E' un app per Android, che impostando un scadenza,
 ti aiuta a concentrarti fino a quel momento,
 ricordandoti con una notifica che non dovresti distrarti con il telefono,
 nel caso non stessi rispettando la scadenza.